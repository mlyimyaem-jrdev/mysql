<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const posts = ref([])
const page = ref(1)
const totalPages = ref(1)
const loading = ref(false)
const error = ref('')
const limit = 10

async function fetchPosts() {
  loading.value = true
  error.value = ''

  try {
    const response = await axios.get('https://jsonplaceholder.typicode.com/posts', {
      params: { _page: page.value, _limit: limit }
    })

    posts.value = response.data
    const total = Number(response.headers['x-total-count'] ?? 100)
    totalPages.value = Math.ceil(total / limit)
  } catch (err) {
    error.value = 'Could not load posts. Please try again.'
    posts.value = []
  } finally {
    loading.value = false
  }
}

function changePage(nextPage) {
  if (loading.value || nextPage < 1 || nextPage > totalPages.value) return
  page.value = nextPage
  fetchPosts()
}

onMounted(fetchPosts)
</script>

<template>
  <main class="container py-5">
    <h1 class="mb-4">Posts</h1>

    <div v-if="error" class="alert alert-danger" role="alert">
      {{ error }}
      <button class="btn btn-sm btn-outline-danger ms-2" @click="fetchPosts">Retry</button>
    </div>

    <div v-if="loading" class="text-secondary mb-3">Loading...</div>

    <ul v-else class="list-group mb-4">
      <li v-for="post in posts" :key="post.id" class="list-group-item">
        <strong>{{ post.id }}. {{ post.title }}</strong>
        <p class="mb-0 text-secondary">{{ post.body }}</p>
      </li>
    </ul>

    <div class="d-flex align-items-center gap-3">
      <button class="btn btn-primary" :disabled="page === 1 || loading" @click="changePage(page - 1)">
        Previous
      </button>
      <span>Page {{ page }} of {{ totalPages }}</span>
      <button class="btn btn-primary" :disabled="page === totalPages || loading" @click="changePage(page + 1)">
        Next
      </button>
    </div>
  </main>
</template>
