# Vue 3 + Bootstrap + Axios Pagination

A small working Vue 3 app that fetches posts from [JSONPlaceholder](https://jsonplaceholder.typicode.com/) and displays 10 posts per page.

## Run

```bash
npm install
npm run dev
```

Open the local URL shown by Vite (usually `http://localhost:5173`).

## Files

- `src/main.js` — loads Bootstrap and mounts the app.
- `src/App.vue` — fetches posts, renders them, and handles pagination.

## How it works

1. `onMounted(fetchPosts)` loads page 1.
2. Axios requests `/posts?_page=1&_limit=10`.
3. The `Next` button increments `page` and fetches the next 10 records.
4. The `Previous` button decrements `page`.
5. Bootstrap styles the list and buttons.

The API usually returns an `x-total-count` header; the example uses 100 as a fallback for JSONPlaceholder's known posts dataset. For a custom API, replace that fallback with your server's total-count field.
