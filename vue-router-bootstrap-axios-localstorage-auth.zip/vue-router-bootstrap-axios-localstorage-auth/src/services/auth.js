import { ref } from 'vue'

const TOKEN_KEY = 'accessToken'

// Shared reactive login state, restored after browser refresh.
export const authToken = ref(localStorage.getItem(TOKEN_KEY) || '')

export function saveToken(token) {
  localStorage.setItem(TOKEN_KEY, token)
  authToken.value = token
}

export function logout() {
  authToken.value = ''
  // Remove tokens from BOTH stores, including any older session-based login.
  localStorage.removeItem(TOKEN_KEY)
  sessionStorage.removeItem(TOKEN_KEY)
  localStorage.removeItem('authToken')
  sessionStorage.removeItem('authToken')
}
