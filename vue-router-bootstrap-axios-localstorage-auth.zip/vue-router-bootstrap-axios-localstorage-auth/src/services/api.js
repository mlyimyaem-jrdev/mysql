import axios from 'axios'
import { authToken } from './auth'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'https://dummyjson.com'
})

api.interceptors.request.use(config => {
  // Read the latest token for every request (including after refresh).
  if (authToken.value) {
    config.headers.Authorization = `Bearer ${authToken.value}`
  } else {
    delete config.headers.Authorization
  }
  return config
})

export default api
