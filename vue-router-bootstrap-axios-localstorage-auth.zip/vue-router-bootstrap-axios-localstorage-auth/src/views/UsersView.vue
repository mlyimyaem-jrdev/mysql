<script setup>
import { ref, computed, onMounted } from 'vue'
import api from '../services/api'
const users = ref([])
const total = ref(0)
const page = ref(1)
const limit = 10
const loading = ref(false)
const error = ref('')
const totalPages = computed(() => Math.max(1, Math.ceil(total.value / limit)))
async function fetchUsers() {
  loading.value = true
  error.value = ''
  try {
    const { data } = await api.get('/users', { params: { limit, skip: (page.value - 1) * limit } })
    users.value = data.users
    total.value = data.total
  } catch { error.value = 'Unable to load users.' }
  finally { loading.value = false }
}
function changePage(next) {
  if (next < 1 || next > totalPages.value) return
  page.value = next
  fetchUsers()
}
onMounted(fetchUsers)
</script>
<template>
  <h1>Users</h1>
  <p class="text-secondary">The Users page demonstrates API-side pagination.</p>
  <p v-if="loading">Loading...</p>
  <p v-else-if="error" class="alert alert-danger">{{ error }}</p>
  <template v-else>
    <div class="list-group">
      <RouterLink v-for="user in users" :key="user.id" :to="`/users/${user.id}`" class="list-group-item list-group-item-action">
        {{ user.firstName }} {{ user.lastName }} <small class="text-muted">({{ user.email }})</small>
      </RouterLink>
    </div>
    <div class="d-flex justify-content-between align-items-center mt-4">
      <button class="btn btn-outline-primary" :disabled="page === 1" @click="changePage(page - 1)">Previous</button>
      <span>Page {{ page }} of {{ totalPages }}</span>
      <button class="btn btn-primary" :disabled="page === totalPages" @click="changePage(page + 1)">Next</button>
    </div>
  </template>
</template>
