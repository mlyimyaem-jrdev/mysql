<script setup>
import { ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import api from '../services/api'
const route = useRoute()
const user = ref(null)
const error = ref('')
const loading = ref(false)
watch(() => route.params.id, async (id) => {
  loading.value = true
  user.value = null
  error.value = ''
  try { const { data } = await api.get(`/users/${id}`); user.value = data }
  catch { error.value = 'Unable to load user.' }
  finally { loading.value = false }
}, { immediate: true })
</script>
<template>
  <RouterLink to="/users" class="btn btn-link ps-0">Back to users</RouterLink>
  <p v-if="loading">Loading...</p>
  <p v-else-if="error" class="alert alert-danger">{{ error }}</p>
  <div v-else-if="user" class="card"><div class="card-body">
    <img :src="user.image" :alt="user.firstName" width="90" height="90" />
    <h1 class="h3 mt-2">{{ user.firstName }} {{ user.lastName }}</h1>
    <p>Email: {{ user.email }}</p><p>Phone: {{ user.phone }}</p><p>Company: {{ user.company?.name }}</p>
  </div></div>
</template>
