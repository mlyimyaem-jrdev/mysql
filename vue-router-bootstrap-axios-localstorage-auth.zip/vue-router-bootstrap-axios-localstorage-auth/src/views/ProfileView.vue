<script setup>
import { ref, watch, onMounted } from 'vue'
import api from '../services/api'
import { authToken, saveToken, logout as clearSession } from '../services/auth'

const username = ref('emilys')
const password = ref('emilyspass')
const profile = ref(null)
const error = ref('')
const loading = ref(false)

async function fetchProfile() {
  const { data } = await api.get('/auth/me')
  profile.value = data
}

async function login() {
  loading.value = true
  error.value = ''
  try {
    const { data } = await api.post('/auth/login', {
      username: username.value,
      password: password.value,
      expiresInMins: 30
    })
    saveToken(data.accessToken)
    await fetchProfile()
    password.value = ''
  } catch {
    clearSession()
    profile.value = null
    error.value = 'Login failed. Check your credentials.'
  } finally {
    loading.value = false
  }
}

function logout() {
  clearSession()
  profile.value = null
  error.value = ''
  password.value = ''
}

async function restoreProfile() {
  if (!authToken.value) return
  loading.value = true
  try {
    await fetchProfile()
  } catch {
    logout() // Expired or invalid saved token
    error.value = 'Your saved session expired. Please log in again.'
  } finally {
    loading.value = false
  }
}

// Handles logout from the navbar while this page is open.
watch(authToken, token => {
  if (!token) profile.value = null
})
onMounted(restoreProfile)
</script>

<template>
  <h1>My Profile (Authorized API)</h1>
  <p class="text-secondary">Login is saved in localStorage and restored on refresh. Logout clears saved tokens.</p>

  <p v-if="loading" class="text-secondary">Loading...</p>
  <div v-if="error" class="alert alert-danger">{{ error }}</div>

  <div v-if="!authToken && !loading" class="card" style="max-width: 440px">
    <form class="card-body" @submit.prevent="login">
      <label class="form-label">Username</label>
      <input v-model="username" class="form-control mb-3" required autocomplete="username" />
      <label class="form-label">Password</label>
      <input v-model="password" type="password" class="form-control mb-3" required autocomplete="current-password" />
      <button class="btn btn-primary" :disabled="loading">Login</button>
    </form>
  </div>

  <div v-if="profile" class="card">
    <div class="card-body">
      <h2>{{ profile.firstName }} {{ profile.lastName }}</h2>
      <p>{{ profile.email }}</p>
      <button class="btn btn-outline-danger" @click="logout">Logout</button>
    </div>
  </div>
</template>
