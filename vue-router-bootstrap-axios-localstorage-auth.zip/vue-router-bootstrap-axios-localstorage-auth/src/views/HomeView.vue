<template>
  <h1>Vue + Axios Example</h1>
  <p>Explore posts with frontend filtering and sorting, browse users, or try the authorized profile API.</p>
  <RouterLink to="/posts" class="btn btn-primary me-2">Browse Posts</RouterLink>
  <RouterLink to="/users" class="btn btn-outline-primary">Browse Users</RouterLink>
</template>
