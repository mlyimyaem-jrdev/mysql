<script setup>
import { ref, computed, onMounted } from 'vue'
import api from '../services/api'

const posts = ref([])
const search = ref('')
const tag = ref('all')
const sort = ref('id-desc')
const page = ref(1)
const perPage = 9
const loading = ref(false)
const error = ref('')

// Load all records once: sorting, filtering, and paging happen in Vue.
async function fetchPosts() {
  loading.value = true
  error.value = ''
  try {
    const { data } = await api.get('/posts', { params: { limit: 0 } })
    posts.value = data.posts
  } catch {
    error.value = 'Unable to fetch posts. Please try again.'
  } finally {
    loading.value = false
  }
}

const tags = computed(() => [...new Set(posts.value.flatMap(post => post.tags || []))].sort())

const filteredPosts = computed(() => {
  const keyword = search.value.trim().toLowerCase()
  const [field, direction] = sort.value.split('-')
  return posts.value
    .filter(post =>
      (tag.value === 'all' || post.tags?.includes(tag.value)) &&
      (!keyword || `${post.title} ${post.body}`.toLowerCase().includes(keyword))
    )
    .sort((a, b) => {
      const comparison = field === 'title'
        ? a.title.localeCompare(b.title)
        : Number(a[field]) - Number(b[field])
      return direction === 'asc' ? comparison : -comparison
    })
})

const totalPages = computed(() => Math.max(1, Math.ceil(filteredPosts.value.length / perPage)))
const visiblePosts = computed(() => filteredPosts.value.slice((page.value - 1) * perPage, page.value * perPage))

function resetPage() { page.value = 1 }
function changePage(next) {
  if (next >= 1 && next <= totalPages.value) page.value = next
}

onMounted(fetchPosts)
</script>

<template>
  <h1 class="mb-3">Posts</h1>
  <p class="text-secondary">Search, tag filtering, sorting, and pagination are all performed in the frontend.</p>
  <div class="row g-2 mb-4">
    <div class="col-md-5">
      <input v-model="search" @input="resetPage" class="form-control" placeholder="Search title or body..." aria-label="Search posts" />
    </div>
    <div class="col-md-3">
      <select v-model="tag" @change="resetPage" class="form-select" aria-label="Filter by tag">
        <option value="all">All tags</option>
        <option v-for="t in tags" :key="t" :value="t">{{ t }}</option>
      </select>
    </div>
    <div class="col-md-4">
      <select v-model="sort" @change="resetPage" class="form-select" aria-label="Sort posts">
        <option value="id-desc">ID: Newest first</option>
        <option value="id-asc">ID: Oldest first</option>
        <option value="title-asc">Title: A–Z</option>
        <option value="title-desc">Title: Z–A</option>
        <option value="views-desc">Views: High to low</option>
        <option value="views-asc">Views: Low to high</option>
      </select>
    </div>
  </div>

  <p v-if="loading">Loading posts...</p>
  <div v-else-if="error" class="alert alert-danger">{{ error }} <button class="btn btn-sm btn-outline-danger ms-2" @click="fetchPosts">Retry</button></div>
  <template v-else>
    <p class="text-muted">{{ filteredPosts.length }} matching posts</p>
    <div class="row g-3">
      <div v-for="post in visiblePosts" :key="post.id" class="col-md-6 col-lg-4">
        <div class="card h-100 shadow-sm">
          <div class="card-body">
            <h5 class="card-title">{{ post.title }}</h5>
            <p class="card-text">{{ post.body }}</p>
            <span v-for="t in post.tags" :key="t" class="badge text-bg-secondary me-1">{{ t }}</span>
          </div>
          <div class="card-footer text-muted">Post #{{ post.id }} · {{ post.views }} views</div>
        </div>
      </div>
    </div>
    <p v-if="!visiblePosts.length" class="alert alert-info">No posts match your filters.</p>
    <div class="d-flex justify-content-between align-items-center mt-4">
      <button class="btn btn-outline-primary" :disabled="page === 1" @click="changePage(page - 1)">Previous</button>
      <span>Page {{ page }} of {{ totalPages }}</span>
      <button class="btn btn-primary" :disabled="page === totalPages" @click="changePage(page + 1)">Next</button>
    </div>
  </template>
</template>
