import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import PostsView from '../views/PostsView.vue'
import UsersView from '../views/UsersView.vue'
import UserProfileView from '../views/UserProfileView.vue'
import ProfileView from '../views/ProfileView.vue'

export default createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/', component: HomeView },
    { path: '/posts', component: PostsView },
    { path: '/users', component: UsersView },
    { path: '/users/:id', component: UserProfileView },
    { path: '/profile', component: ProfileView }
  ]
})
