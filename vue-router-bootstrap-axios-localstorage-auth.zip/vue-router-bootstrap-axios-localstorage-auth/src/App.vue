<script setup>
import { authToken, logout } from './services/auth'
</script>

<template>
  <nav class="navbar navbar-expand navbar-dark bg-dark">
    <div class="container gap-3 flex-wrap">
      <RouterLink class="navbar-brand" to="/">Vue Demo</RouterLink>
      <div class="navbar-nav flex-row gap-3 flex-wrap align-items-center">
        <RouterLink class="nav-link" to="/posts">Posts</RouterLink>
        <RouterLink class="nav-link" to="/users">Users</RouterLink>
        <RouterLink class="nav-link" to="/profile">My Profile</RouterLink>
        <button v-if="authToken" class="btn btn-outline-light btn-sm" @click="logout">
          Logout
        </button>
      </div>
    </div>
  </nav>
  <main class="container py-4"><RouterView /></main>
</template>
