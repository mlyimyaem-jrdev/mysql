# Vue Router + Bootstrap + Axios — Frontend Post Filters

A minimal Vue 3 + Vite application with:

- **Posts (`/posts`)**: fetch all DummyJSON posts once using `GET /posts?limit=0`, then **search, tag-filter, sort, and paginate in Vue**.
- **Users (`/users`)**: API-side pagination using `limit` and `skip`.
- **User Profile (`/users/:id`)**: public single-user API endpoint.
- **My Profile (`/profile`)**: demo authentication using `POST /auth/login` and `GET /auth/me`.

## Setup

```bash
npm install
npm run dev
```

Open the local address printed by Vite (typically http://localhost:5173).

## Configuration

`.env` contains:

```env
VITE_API_BASE_URL=https://dummyjson.com
```

`src/services/api.js` configures Axios once. The login access token is saved under `localStorage.accessToken`. The Axios request interceptor automatically sends it as `Authorization: Bearer <token>`.

### Authentication / Logout

1. Visit `/profile` and use the demo credentials `emilys` / `emilyspass`.
2. A successful login saves the returned `accessToken` in `localStorage`, then calls `GET /auth/me`.
3. Refresh the page: the token is restored and `/auth/me` is fetched again.
4. Click **Logout** in the navbar or profile. It clears `accessToken` (and legacy `authToken` keys) from both `localStorage` and `sessionStorage` and resets the in-memory auth state.
5. Expired/invalid saved tokens are cleared when `/auth/me` fails.

**Security:** localStorage tokens are accessible to JavaScript and vulnerable to XSS. This is a teaching demo. In production, prefer secure HttpOnly cookies where practical, use strong XSS defenses, and implement appropriate token expiration/rotation. Logout here only clears client-side state; it does not revoke a server-issued token.

## Frontend Posts filtering and sorting

`src/views/PostsView.vue` demonstrates four stages:

1. `fetchPosts()` loads all available posts into `posts` using `limit: 0`.
2. `filteredPosts` is a Vue `computed` property that filters by search terms and selected tag, then sorts by ID, title, or views.
3. `visiblePosts` applies `.slice(...)` to show only the currently selected *frontend* page.
4. The Previous/Next buttons move between pages of **filtered results**, resetting to page 1 whenever a filter or sort changes.

This is easy to understand and suitable for small datasets. **All posts are downloaded to the browser**, unlike server-side pagination. For larger datasets, prefer backend filtering/sorting/pagination.

## API endpoints

- `GET /posts?limit=0`
- `GET /users?limit=10&skip=0`
- `GET /users/:id`
- `POST /auth/login` (sample credentials `emilys` / `emilyspass`)
- `GET /auth/me` with Bearer token

DummyJSON is a sample API, not a production identity provider.
