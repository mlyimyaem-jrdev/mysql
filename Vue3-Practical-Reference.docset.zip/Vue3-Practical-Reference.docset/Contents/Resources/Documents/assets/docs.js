(function () {
  "use strict";

  function qs(sel, root) {
    return (root || document).querySelector(sel);
  }
  function qsa(sel, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(sel));
  }

  /* Collapsible sidebar groups */
  qsa(".nav-group > button").forEach(function (btn) {
    btn.addEventListener("click", function () {
      btn.parentElement.classList.toggle("collapsed");
    });
  });

  /* Active nav highlight from body[data-page] */
  var page = document.body.getAttribute("data-page");
  if (page) {
    qsa('.nav-links a[data-nav="' + page + '"]').forEach(function (a) {
      a.classList.add("active");
      var group = a.closest(".nav-group");
      if (group) group.classList.remove("collapsed");
    });
  }

  /* Sidebar filter */
  var search = qs("#nav-filter");
  if (search) {
    search.addEventListener("input", function () {
      var q = search.value.trim().toLowerCase();
      qsa(".nav-group").forEach(function (group) {
        var links = qsa(".nav-links a", group);
        var any = false;
        links.forEach(function (a) {
          var show = !q || a.textContent.toLowerCase().indexOf(q) !== -1;
          a.style.display = show ? "" : "none";
          if (show) any = true;
        });
        group.style.display = any || !q ? "" : "none";
        if (q && any) group.classList.remove("collapsed");
      });
    });
  }

  /* Copy buttons */
  qsa(".pre-wrap").forEach(function (wrap) {
    var btn = qs(".copy-btn", wrap);
    var code = qs("pre code", wrap) || qs("pre", wrap);
    if (!btn || !code) return;
    btn.addEventListener("click", function () {
      var text = code.textContent || "";
      function done() {
        btn.textContent = "Copied";
        btn.classList.add("copied");
        setTimeout(function () {
          btn.textContent = "Copy";
          btn.classList.remove("copied");
        }, 1400);
      }
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done).catch(function () {
          fallbackCopy(text, done);
        });
      } else {
        fallbackCopy(text, done);
      }
    });
  });

  function fallbackCopy(text, done) {
    var ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.left = "-9999px";
    document.body.appendChild(ta);
    ta.select();
    try {
      document.execCommand("copy");
      done();
    } catch (e) {
      /* ignore */
    }
    document.body.removeChild(ta);
  }

  /* Very small highlighter for offline use */
  qsa("pre code[data-lang]").forEach(function (el) {
    var lang = el.getAttribute("data-lang");
    if (el.getAttribute("data-highlighted") === "1") return;
    var raw = el.textContent;
    el.innerHTML = highlight(raw, lang);
    el.setAttribute("data-highlighted", "1");
  });

  function escapeHtml(s) {
    return s
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function highlight(src, lang) {
    var escaped = escapeHtml(src);
    if (lang === "html" || lang === "vue") {
      return escaped
        .replace(/(&lt;!--[\s\S]*?--&gt;)/g, '<span class="tok-cm">$1</span>')
        .replace(/(&lt;\/?[a-zA-Z0-9:-]+)(.*?)(\/?&gt;)/g, function (_, tag, attrs, end) {
          attrs = attrs.replace(/([:@]?[a-zA-Z_:][\w:.-]*)(=)/g, '<span class="tok-attr">$1</span>$2');
          attrs = attrs.replace(/(&quot;[^]*?&quot;|&#39;[^]*?&#39;)/g, '<span class="tok-str">$1</span>');
          return '<span class="tok-tag">' + tag + "</span>" + attrs + '<span class="tok-tag">' + end + "</span>";
        });
    }
    if (lang === "js" || lang === "javascript" || lang === "json" || lang === "shell" || lang === "bash" || lang === "dotenv") {
      var out = "";
      var i = 0;
      while (i < escaped.length) {
        if (escaped.slice(i, i + 2) === "//") {
          var endLine = escaped.indexOf("\n", i);
          if (endLine < 0) endLine = escaped.length;
          out += '<span class="tok-cm">' + escaped.slice(i, endLine) + "</span>";
          i = endLine;
          continue;
        }
        if (escaped[i] === "/" && escaped[i + 1] === "*") {
          var endC = escaped.indexOf("*/", i + 2);
          if (endC < 0) endC = escaped.length - 2;
          out += '<span class="tok-cm">' + escaped.slice(i, endC + 2) + "</span>";
          i = endC + 2;
          continue;
        }
        if (escaped[i] === "&" && escaped.slice(i, i + 6) === "&quot;") {
          var j = escaped.indexOf("&quot;", i + 6);
          if (j < 0) j = escaped.length - 6;
          out += '<span class="tok-str">' + escaped.slice(i, j + 6) + "</span>";
          i = j + 6;
          continue;
        }
        if (escaped[i] === "'") {
          var k = i + 1;
          while (k < escaped.length && escaped[k] !== "'" && escaped[k] !== "\n") k++;
          out += '<span class="tok-str">' + escaped.slice(i, k + 1) + "</span>";
          i = k + 1;
          continue;
        }
        if (escaped[i] === "`") {
          var t = i + 1;
          while (t < escaped.length && escaped[t] !== "`") t++;
          out += '<span class="tok-str">' + escaped.slice(i, t + 1) + "</span>";
          i = t + 1;
          continue;
        }
        var num = escaped.slice(i).match(/^\d+(?:\.\d+)?/);
        if (num && (i === 0 || /[\s(,=:[{\-+*/%!<>|&?]/.test(escaped[i - 1] || " "))) {
          out += '<span class="tok-num">' + num[0] + "</span>";
          i += num[0].length;
          continue;
        }
        var word = escaped.slice(i).match(/^[A-Za-z_$][\w$]*/);
        if (word) {
          var w = word[0];
          var kw =
            /^(?:const|let|var|function|return|if|else|async|await|import|from|export|default|new|try|catch|finally|throw|class|extends|typeof|instanceof|in|of|for|while|do|switch|case|break|continue|null|undefined|true|false|this|super)$/.test(
              w
            );
          if (kw) out += '<span class="tok-kw">' + w + "</span>";
          else if (/^[A-Z]/.test(w)) out += '<span class="tok-fn">' + w + "</span>";
          else out += w;
          i += w.length;
          continue;
        }
        out += escaped[i];
        i += 1;
      }
      return out;
    }
    if (lang === "css") {
      return escaped
        .replace(/(\/\*[\s\S]*?\*\/)/g, '<span class="tok-cm">$1</span>')
        .replace(/([a-zA-Z-]+)(\s*:)/g, '<span class="tok-attr">$1</span>$2')
        .replace(/(#[0-9a-fA-F]{3,8}|\b\d+(?:px|rem|em|%|vh|vw)?\b)/g, '<span class="tok-num">$1</span>');
    }
    return escaped;
  }
})();
