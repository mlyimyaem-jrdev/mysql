import axios from 'axios'
import { useAuth } from '../stores/auth.js'

const api = axios.create({ baseURL: '/api', timeout: 12000 })
api.interceptors.request.use(config => {
  const { state } = useAuth()
  if (state.token) config.headers.Authorization = `Bearer ${state.token}`
  return config
})
api.interceptors.response.use(
  response => response,
  error => {
    if (error.response?.status === 401 && !error.config?.url?.startsWith('/auth/login')) {
      useAuth().logout()
    }
    return Promise.reject(error)
  }
)
export const errorMessage = error => error.response?.data?.message || error.message || 'Request failed'
export default api
