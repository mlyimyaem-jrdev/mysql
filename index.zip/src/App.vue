<script setup>
import { ref, watch } from 'vue'
import { RouterView, useRouter } from 'vue-router'
import { useAuth } from './stores/auth.js'
import { useCart } from './stores/cart.js'

const { state, isLoggedIn, isSeller, isCustomer, logout } = useAuth()
const cart = useCart()
const router = useRouter()
const menuOpen = ref(false)

watch(
  [isLoggedIn, isCustomer],
  async ([loggedIn, customer]) => {
    if (loggedIn && customer) {
      try { await cart.refresh() }
      catch { cart.clear() }
    } else cart.clear()
  },
  { immediate: true },
)

function signOut() {
  logout()
  cart.clear()
  menuOpen.value = false
  router.push('/login')
}

function closeMenu() {
  menuOpen.value = false
}
</script>

<template>
  <div class="d-flex flex-column min-vh-100">
    <header class="sticky-top bg-dark">
      <nav class="navbar navbar-expand-lg navbar-dark container py-3">
        <RouterLink to="/products" class="navbar-brand fw-bold d-flex align-items-center gap-2">
          <span class="bg-warning text-dark rounded px-2 py-1">
            <i class="bi bi-bag-heart-fill"></i>
          </span>
          CartCraft
        </RouterLink>

        <button class="navbar-toggler" type="button" aria-label="Toggle navigation" @click="menuOpen = !menuOpen">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" :class="{ show: menuOpen }">
          <div class="navbar-nav me-auto ms-lg-4">
            <RouterLink to="/products" class="nav-link" @click="closeMenu">Shop</RouterLink>
            <RouterLink v-if="isCustomer" to="/orders" class="nav-link" @click="closeMenu">My orders</RouterLink>
            <RouterLink v-if="isSeller" to="/seller/products" class="nav-link" @click="closeMenu">Seller dashboard</RouterLink>
          </div>

          <div class="d-flex align-items-center flex-wrap gap-2 mt-3 mt-lg-0">
            <RouterLink v-if="isCustomer" to="/cart" class="btn btn-outline-light btn-sm" @click="closeMenu">
              <i class="bi bi-cart3 me-1"></i> Cart
              <span class="badge text-bg-warning ms-1">{{ cart.count.value }}</span>
            </RouterLink>

            <span v-if="isLoggedIn" class="small text-white-50">Hi, {{ state.user?.name }}</span>
            <button v-if="isLoggedIn" class="btn btn-outline-light btn-sm" @click="signOut">Logout</button>

            <template v-else>
              <RouterLink to="/login" class="btn btn-outline-light btn-sm" @click="closeMenu">Login</RouterLink>
              <RouterLink to="/register" class="btn btn-warning btn-sm" @click="closeMenu">Join now</RouterLink>
            </template>
          </div>
        </div>
      </nav>
    </header>

    <main class="flex-grow-1"><RouterView /></main>

    <footer class="bg-light border-top py-4 mt-5">
      <div class="container d-flex flex-wrap justify-content-between gap-3">
        <span class="fw-semibold">CartCraft <span class="fw-normal text-secondary">/ demo edition</span></span>
        <small class="text-secondary">Local mock API • Vue 3 • Bootstrap 5</small>
      </div>
    </footer>
  </div>
</template>
