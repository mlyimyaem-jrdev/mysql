<script setup>
import { onMounted, ref } from 'vue'
import api, { errorMessage } from '../services/api.js'
import AlertMessage from '../components/AlertMessage.vue'

const orders = ref([])
const loading = ref(true)
const error = ref('')

onMounted(async () => {
  try {
    orders.value = (await api.get('/orders')).data.data
  } catch (err) {
    error.value = errorMessage(err)
  } finally {
    loading.value = false
  }
})
</script>

<template>
  <div class="container py-5">
    <div class="small text-uppercase fw-bold text-secondary mb-2">Account</div>
    <h1 class="fw-bold mb-4">My orders</h1>
    <AlertMessage :message="error" />

    <div v-if="loading" class="spinner-border" role="status"></div>

    <div v-else-if="!orders.length" class="card shadow-sm border-0 text-center p-5">
      <div class="card-body">
        <i class="bi bi-receipt display-1 text-secondary"></i>
        <h4 class="mt-3">No orders yet</h4>
        <RouterLink to="/products" class="btn btn-dark mt-2">Start shopping</RouterLink>
      </div>
    </div>

    <div v-for="order in orders" :key="order.id" class="card shadow-sm mb-3">
      <div class="card-body p-4">
        <div class="d-flex flex-wrap justify-content-between gap-2 mb-3">
          <div>
            <div class="small text-uppercase fw-bold text-secondary mb-1">
              Order {{ order.id.slice(0, 8) }}
            </div>
            <small class="text-secondary">{{ new Date(order.createdAt).toLocaleString() }}</small>
          </div>
          <span class="badge text-bg-success align-self-start">{{ order.status }}</span>
        </div>

        <div
          v-for="item in order.items"
          :key="item.productId"
          class="d-flex justify-content-between gap-3 py-2 border-bottom"
        >
          <span>{{ item.name }} × {{ item.quantity }}</span>
          <span>₱{{ item.lineTotal.toFixed(2) }}</span>
        </div>

        <div class="d-flex justify-content-between mt-3 fw-bold">
          <span>Total</span>
          <span>₱{{ order.total.toFixed(2) }}</span>
        </div>
        <div class="text-secondary small mt-2">Deliver to: {{ order.shippingAddress }}</div>
      </div>
    </div>
  </div>
</template>
