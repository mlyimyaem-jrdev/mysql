<script setup>
import { onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { useCart } from '../stores/cart.js'
import api, { errorMessage } from '../services/api.js'
import AlertMessage from '../components/AlertMessage.vue'

const router = useRouter()
const cart = useCart()
const loading = ref(true)
const busyId = ref('')
const checkoutBusy = ref(false)
const error = ref('')
const address = ref('')

onMounted(async () => {
  try {
    await cart.refresh()
  } catch (err) {
    error.value = errorMessage(err)
  } finally {
    loading.value = false
  }
})

async function setQuantity(id, amount) {
  busyId.value = id
  error.value = ''
  try {
    await cart.update(id, Number(amount))
  } catch (err) {
    error.value = errorMessage(err)
  } finally {
    busyId.value = ''
  }
}

async function remove(id) {
  busyId.value = id
  error.value = ''
  try {
    await cart.remove(id)
  } catch (err) {
    error.value = errorMessage(err)
  } finally {
    busyId.value = ''
  }
}

async function checkout() {
  checkoutBusy.value = true
  error.value = ''
  try {
    await api.post('/orders', { shippingAddress: address.value.trim() })
    cart.clear()
    await router.push('/orders')
  } catch (err) {
    error.value = errorMessage(err)
  } finally {
    checkoutBusy.value = false
  }
}
</script>

<template>
  <div class="container py-5">
    <div class="small text-uppercase fw-bold text-secondary mb-2">Checkout</div>
    <h1 class="fw-bold mb-4">Your cart</h1>
    <AlertMessage :message="error" />

    <div v-if="loading" class="spinner-border" role="status"></div>

    <div v-else-if="!cart.state.items.length" class="card shadow-sm border-0 text-center py-5">
      <div class="card-body">
        <i class="bi bi-cart-x display-1 text-secondary"></i>
        <h3 class="mt-3">Your cart is empty</h3>
        <p class="text-secondary">Start by exploring the collection.</p>
        <RouterLink to="/products" class="btn btn-dark">Browse products</RouterLink>
      </div>
    </div>

    <div v-else class="row g-4">
      <div class="col-lg-8">
        <div class="card shadow-sm">
          <div class="card-body p-3 p-md-4">
            <div
              v-for="item in cart.state.items"
              :key="item.productId"
              class="d-flex align-items-center flex-wrap gap-3 py-3 border-bottom"
            >
              <img
                v-if="item.product.imageUrl"
                :src="item.product.imageUrl"
                :alt="item.product.name"
                class="rounded object-fit-cover bg-light"
                style="width: 90px; height: 72px"
              />
              <div
                v-else
                class="rounded bg-light d-flex align-items-center justify-content-center"
                style="width: 90px; height: 72px"
              >
                <i class="bi bi-image"></i>
              </div>

              <div class="flex-grow-1">
                <RouterLink :to="`/products/${item.productId}`" class="text-dark text-decoration-none fw-semibold">
                  {{ item.product.name }}
                </RouterLink>
                <div class="small text-secondary">₱{{ item.product.price.toFixed(2) }} / item</div>
              </div>

              <select
                class="form-select form-select-sm"
                style="width: 82px"
                :value="item.quantity"
                :disabled="busyId === item.productId"
                :aria-label="`Quantity for ${item.product.name}`"
                @change="setQuantity(item.productId, $event.target.value)"
              >
                <option v-for="n in Math.min(item.product.stock, 20)" :key="n" :value="n">{{ n }}</option>
              </select>

              <strong>₱{{ item.lineTotal.toFixed(2) }}</strong>
              <button
                class="btn btn-outline-danger btn-sm"
                :disabled="busyId === item.productId"
                aria-label="Remove product"
                @click="remove(item.productId)"
              >
                <i class="bi bi-trash"></i>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-4">
        <div class="card shadow-sm">
          <div class="card-body p-4">
            <h4 class="mb-4">Order summary</h4>
            <div class="d-flex justify-content-between mb-3">
              <span class="text-secondary">Items ({{ cart.count.value }})</span>
              <strong>₱{{ cart.state.total.toFixed(2) }}</strong>
            </div>
            <div class="d-flex justify-content-between mb-4">
              <span class="text-secondary">Shipping</span>
              <span>Free (demo)</span>
            </div>
            <hr />
            <div class="d-flex justify-content-between fs-5 fw-bold mb-4">
              <span>Total</span>
              <span>₱{{ cart.state.total.toFixed(2) }}</span>
            </div>

            <form @submit.prevent="checkout">
              <label for="address" class="form-label">Shipping address</label>
              <textarea
                id="address"
                v-model="address"
                class="form-control mb-3"
                minlength="10"
                maxlength="500"
                rows="3"
                placeholder="House no., street, city, province"
                required
              ></textarea>
              <button class="btn btn-warning w-100" :disabled="checkoutBusy">
                {{ checkoutBusy ? 'Placing order...' : 'Place order' }}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
