<script setup>
import { computed, onMounted, ref } from 'vue'
import api, { errorMessage } from '../services/api.js'
import ProductCard from '../components/ProductCard.vue'
import AlertMessage from '../components/AlertMessage.vue'

const products = ref([])
const loading = ref(true)
const error = ref('')
const search = ref('')
const category = ref('')
const categories = ['Electronics', 'Fashion', 'Home', 'Lifestyle', 'Other']

const filtered = computed(() =>
  products.value.filter((product) => {
    const matchName = `${product.name} ${product.description}`
      .toLowerCase()
      .includes(search.value.toLowerCase())
    return matchName && (!category.value || product.category === category.value)
  }),
)

async function load() {
  loading.value = true
  error.value = ''
  try {
    products.value = (await api.get('/products')).data.data
  } catch (err) {
    error.value = errorMessage(err)
  } finally {
    loading.value = false
  }
}

onMounted(load)
</script>

<template>
  <div class="container py-4 py-lg-5">
    <section class="bg-dark text-white rounded-4 p-4 p-md-5 mb-5 d-flex justify-content-between align-items-center">
      <div>
        <div class="small text-uppercase fw-bold text-info mb-3">A better everyday shop</div>
        <h1 class="fw-bold mb-3">Find your next favorite thing.</h1>
        <p class="text-white-50 mb-0">Thoughtful essentials, good prices, and a simple checkout.</p>
      </div>
      <i class="bi bi-bag-check d-none d-md-block display-1 opacity-25" aria-hidden="true"></i>
    </section>

    <div class="d-flex flex-wrap justify-content-between align-items-end gap-3 mb-4">
      <div>
        <div class="small text-uppercase fw-bold text-secondary mb-1">Browse</div>
        <h2 class="fw-bold mb-0">All products</h2>
      </div>
      <span class="text-secondary">{{ filtered.length }} items</span>
    </div>

    <div class="row g-3 mb-4">
      <div class="col-md-8">
        <label for="search" class="form-label visually-hidden">Search products</label>
        <div class="input-group">
          <span class="input-group-text bg-white"><i class="bi bi-search"></i></span>
          <input id="search" v-model="search" class="form-control" placeholder="Search by name or description" />
        </div>
      </div>
      <div class="col-md-4">
        <label for="category" class="form-label visually-hidden">Category</label>
        <select id="category" v-model="category" class="form-select">
          <option value="">All categories</option>
          <option v-for="item in categories" :key="item" :value="item">{{ item }}</option>
        </select>
      </div>
    </div>

    <AlertMessage :message="error" />

    <div v-if="loading" class="text-center py-5">
      <div class="spinner-border text-secondary" role="status"></div>
      <p class="mt-2 text-secondary">Loading products...</p>
    </div>

    <div v-else-if="!filtered.length" class="card shadow-sm border-0 text-center py-5">
      <div class="card-body">
        <i class="bi bi-search display-1 text-secondary"></i>
        <h4 class="mt-3">No products found</h4>
        <p class="text-secondary mb-0">Try a different search or category.</p>
      </div>
    </div>

    <div v-else class="row g-4">
      <div v-for="product in filtered" :key="product.id" class="col-sm-6 col-lg-4 col-xl-3">
        <ProductCard :product="product" />
      </div>
    </div>
  </div>
</template>
