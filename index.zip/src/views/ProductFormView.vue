<script setup>
import { computed, onBeforeUnmount, onMounted, reactive, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import api, { errorMessage } from '../services/api.js'
import AlertMessage from '../components/AlertMessage.vue'

const route = useRoute()
const router = useRouter()
const editing = computed(() => Boolean(route.params.id))

const form = reactive({
  name: '',
  description: '',
  category: 'Electronics',
  price: '',
  stock: 0,
})
const categories = ['Electronics', 'Fashion', 'Home', 'Lifestyle', 'Other']
const imageFile = ref(null)
const previewUrl = ref('')
const existingImage = ref('')
const error = ref('')
const saving = ref(false)
const loading = ref(false)

function pickFile(event) {
  error.value = ''
  const selected = event.target.files?.[0]
  if (previewUrl.value) URL.revokeObjectURL(previewUrl.value)
  imageFile.value = null
  previewUrl.value = ''
  if (!selected) return

  if (!['image/jpeg', 'image/png', 'image/webp'].includes(selected.type)) {
    error.value = 'Use JPG, PNG, or WebP'
    return
  }
  if (selected.size > 2 * 1024 * 1024) {
    error.value = 'Image must be 2 MB or smaller'
    return
  }

  imageFile.value = selected
  previewUrl.value = URL.createObjectURL(selected)
}

onBeforeUnmount(() => {
  if (previewUrl.value) URL.revokeObjectURL(previewUrl.value)
})

onMounted(async () => {
  if (!editing.value) return
  loading.value = true
  try {
    const product = (await api.get(`/products/${route.params.id}`)).data.data
    Object.assign(form, {
      name: product.name,
      category: product.category,
      description: product.description,
      price: product.price,
      stock: product.stock,
    })
    existingImage.value = product.imageUrl || ''
  } catch (err) {
    error.value = errorMessage(err)
  } finally {
    loading.value = false
  }
})

async function save() {
  error.value = ''
  saving.value = true
  try {
    const payload = {
      name: form.name.trim(),
      description: form.description.trim(),
      category: form.category,
      price: Number(form.price),
      stock: Number(form.stock),
    }
    const response = editing.value
      ? await api.put(`/products/${route.params.id}`, payload)
      : await api.post('/products', payload)

    const productId = response.data.data.id
    if (imageFile.value) {
      const multipart = new FormData()
      multipart.append('image', imageFile.value)
      await api.post(`/products/${productId}/image`, multipart)
    }
    await router.push('/seller/products')
  } catch (err) {
    error.value = errorMessage(err)
    if (!editing.value) {
      error.value += ' If the product was created, open the seller dashboard to upload its image.'
    }
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <div class="container py-5" style="max-width: 920px">
    <RouterLink to="/seller/products" class="text-decoration-none text-secondary">
      ← Seller dashboard
    </RouterLink>
    <div class="small text-uppercase fw-bold text-secondary mt-4 mb-2">Seller tools</div>
    <h1 class="fw-bold mb-4">{{ editing ? 'Edit product' : 'Add product' }}</h1>
    <AlertMessage :message="error" />

    <div v-if="loading" class="spinner-border" role="status"></div>

    <form v-else class="card shadow-sm border-0" @submit.prevent="save">
      <div class="card-body p-4 p-lg-5">
        <div class="row g-4">
          <div class="col-md-7">
            <div class="mb-3">
              <label for="name" class="form-label">Name</label>
              <input id="name" v-model.trim="form.name" class="form-control" minlength="2" maxlength="120" required />
            </div>
            <div class="mb-3">
              <label for="category" class="form-label">Category</label>
              <select id="category" v-model="form.category" class="form-select">
                <option v-for="c in categories" :key="c">{{ c }}</option>
              </select>
            </div>
            <div class="row g-3 mb-3">
              <div class="col-sm-6">
                <label for="price" class="form-label">Price (₱)</label>
                <input id="price" v-model.number="form.price" type="number" min="0.01" max="1000000" step="0.01" class="form-control" required />
              </div>
              <div class="col-sm-6">
                <label for="stock" class="form-label">Stock</label>
                <input id="stock" v-model.number="form.stock" type="number" min="0" max="100000" step="1" class="form-control" required />
              </div>
            </div>
            <div>
              <label for="description" class="form-label">Description</label>
              <textarea id="description" v-model.trim="form.description" minlength="5" maxlength="2000" rows="5" class="form-control" required></textarea>
            </div>
          </div>

          <div class="col-md-5">
            <label for="image" class="form-label">Product image (optional)</label>
            <img
              v-if="previewUrl || existingImage"
              :src="previewUrl || existingImage"
              alt="Product image preview"
              class="img-fluid object-fit-contain bg-light rounded mb-3"
              style="max-height: 260px; min-height: 170px; width: 100%"
            />
            <div
              v-else
              class="bg-light rounded d-flex flex-column align-items-center justify-content-center text-secondary mb-3"
              style="min-height: 170px"
            >
              <i class="bi bi-cloud-arrow-up display-4"></i>
              <span>Choose an image</span>
            </div>
            <input id="image" class="form-control" type="file" accept="image/png,image/jpeg,image/webp" @change="pickFile" />
            <small class="text-secondary d-block mt-2">
              JPG, PNG, or WebP. Maximum 2 MB. Field name: <code>image</code>.
            </small>
          </div>
        </div>

        <hr class="my-4" />
        <div class="d-flex gap-2 justify-content-end">
          <RouterLink to="/seller/products" class="btn btn-outline-secondary">Cancel</RouterLink>
          <button class="btn btn-dark" :disabled="saving">
            {{ saving ? 'Saving...' : editing ? 'Update product' : 'Create product' }}
          </button>
        </div>
      </div>
    </form>
  </div>
</template>
