<script setup>
import { reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import api, { errorMessage } from '../services/api.js'
import AlertMessage from '../components/AlertMessage.vue'

const router = useRouter()
const form = reactive({ name: '', email: '', password: '', confirmPassword: '' })
const loading = ref(false)
const error = ref('')

async function register() {
  error.value = ''
  if (form.password !== form.confirmPassword) {
    error.value = 'Passwords do not match'
    return
  }
  if (form.password.length < 8) {
    error.value = 'Password must contain at least 8 characters'
    return
  }

  loading.value = true
  try {
    await api.post('/auth/register', {
      name: form.name.trim(),
      email: form.email.trim(),
      password: form.password,
    })
    await router.push('/login')
  } catch (err) {
    error.value = errorMessage(err)
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-md-7 col-lg-5">
        <div class="card shadow-sm border-0">
          <div class="card-body p-4 p-md-5">
            <div class="small text-uppercase fw-bold text-secondary mb-2">Create account</div>
            <h1 class="h2 fw-bold mb-2">Join CartCraft</h1>
            <p class="text-secondary mb-4">Registration creates a customer account.</p>

            <AlertMessage :message="error" />

            <form @submit.prevent="register">
              <div class="mb-3">
                <label for="name" class="form-label">Full name</label>
                <input id="name" v-model.trim="form.name" minlength="2" maxlength="100" required class="form-control" autocomplete="name" />
              </div>
              <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input id="email" v-model.trim="form.email" type="email" required class="form-control" autocomplete="email" />
              </div>
              <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input id="password" v-model="form.password" type="password" minlength="8" required class="form-control" autocomplete="new-password" />
              </div>
              <div class="mb-4">
                <label for="confirmation" class="form-label">Confirm password</label>
                <input id="confirmation" v-model="form.confirmPassword" type="password" minlength="8" required class="form-control" autocomplete="new-password" />
              </div>
              <button class="btn btn-dark w-100 py-2" :disabled="loading">
                {{ loading ? 'Creating account...' : 'Create account' }}
              </button>
            </form>

            <p class="small mt-4 mb-0">
              Already have an account? <RouterLink to="/login">Sign in</RouterLink>
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
