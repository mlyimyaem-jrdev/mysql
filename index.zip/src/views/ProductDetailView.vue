<script setup>
import { onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import api, { errorMessage } from '../services/api.js'
import { useAuth } from '../stores/auth.js'
import { useCart } from '../stores/cart.js'
import AlertMessage from '../components/AlertMessage.vue'

const route = useRoute()
const router = useRouter()
const { isLoggedIn, isCustomer } = useAuth()
const cart = useCart()

const product = ref(null)
const loading = ref(true)
const busy = ref(false)
const quantity = ref(1)
const error = ref('')
const success = ref('')

onMounted(async () => {
  try {
    product.value = (await api.get(`/products/${route.params.id}`)).data.data
  } catch (err) {
    error.value = errorMessage(err)
  } finally {
    loading.value = false
  }
})

async function add() {
  if (!isLoggedIn.value) return router.push('/login')
  if (!isCustomer.value) return

  error.value = ''
  success.value = ''
  busy.value = true
  try {
    await cart.add(product.value.id, Number(quantity.value))
    success.value = 'Added to your cart.'
  } catch (err) {
    error.value = errorMessage(err)
  } finally {
    busy.value = false
  }
}

const canAdd = () =>
  !busy.value &&
  product.value?.stock > 0 &&
  Number.isInteger(quantity.value) &&
  quantity.value >= 1 &&
  quantity.value <= product.value.stock &&
  !(isLoggedIn.value && !isCustomer.value)
</script>

<template>
  <div class="container py-5">
    <RouterLink to="/products" class="text-decoration-none text-secondary">← Back to products</RouterLink>

    <div v-if="loading" class="py-5 text-center">
      <div class="spinner-border"></div>
    </div>

    <div v-else-if="product" class="row g-4 g-lg-5 mt-1">
      <div class="col-md-6">
        <div class="card shadow-sm border-0 p-3">
          <img
            v-if="product.imageUrl"
            :src="product.imageUrl"
            :alt="product.name"
            class="img-fluid object-fit-contain bg-light rounded"
            style="max-height: 460px; min-height: 330px; width: 100%"
          />
          <div
            v-else
            class="d-flex justify-content-center align-items-center bg-light rounded"
            style="min-height: 330px"
          >
            <i class="bi bi-image display-1 text-secondary"></i>
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="small text-uppercase fw-bold text-secondary mb-3">{{ product.category }}</div>
        <h1 class="fw-bold">{{ product.name }}</h1>
        <p class="fs-3 fw-bold mt-3">
          ₱{{ product.price.toLocaleString('en-PH', { minimumFractionDigits: 2 }) }}
        </p>
        <p class="text-secondary lh-lg">{{ product.description }}</p>
        <p class="small" :class="product.stock ? 'text-success' : 'text-danger'">
          {{ product.stock ? `${product.stock} units in stock` : 'Out of stock' }}
        </p>

        <AlertMessage :message="error" />
        <AlertMessage :message="success" type="success" />

        <div class="d-flex gap-3 align-items-end mt-4">
          <div style="max-width: 110px">
            <label for="qty" class="form-label">Quantity</label>
            <input
              id="qty"
              v-model.number="quantity"
              type="number"
              min="1"
              :max="product.stock"
              class="form-control"
            />
          </div>
          <button class="btn btn-dark btn-lg" :disabled="!canAdd()" @click="add">
            <i class="bi bi-cart-plus me-2"></i>{{ busy ? 'Adding...' : 'Add to cart' }}
          </button>
        </div>
      </div>
    </div>

    <AlertMessage v-else :message="error || 'Product not found'" />
  </div>
</template>
