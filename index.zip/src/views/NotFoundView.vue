<template>
  <div class="container text-center py-5">
    <div class="display-1 text-secondary"><i class="bi bi-signpost-split"></i></div>
    <h1 class="fw-bold">404 — Page not found</h1>
    <p class="text-secondary">That page does not exist.</p>
    <RouterLink to="/products" class="btn btn-dark">Back to shop</RouterLink>
  </div>
</template>
