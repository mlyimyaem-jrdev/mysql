<script setup>
import { onMounted, ref } from 'vue'
import api, { errorMessage } from '../services/api.js'
import { useAuth } from '../stores/auth.js'
import AlertMessage from '../components/AlertMessage.vue'

const { state } = useAuth()
const products = ref([])
const loading = ref(true)
const error = ref('')
const notice = ref('')
const deleting = ref('')

async function load() {
  loading.value = true
  try {
    const all = (await api.get('/products')).data.data
    products.value = all.filter((p) => p.sellerId === state.user.id)
  } catch (err) {
    error.value = errorMessage(err)
  } finally {
    loading.value = false
  }
}

async function removeProduct(product) {
  if (!confirm(`Delete ${product.name}?`)) return
  error.value = ''
  notice.value = ''
  deleting.value = product.id
  try {
    await api.delete(`/products/${product.id}`)
    products.value = products.value.filter((p) => p.id !== product.id)
    notice.value = 'Product deleted.'
  } catch (err) {
    error.value = errorMessage(err)
  } finally {
    deleting.value = ''
  }
}

onMounted(load)
</script>

<template>
  <div class="container py-5">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
      <div>
        <div class="small text-uppercase fw-bold text-secondary mb-2">Seller tools</div>
        <h1 class="fw-bold mb-0">My products</h1>
      </div>
      <RouterLink to="/seller/products/new" class="btn btn-dark">
        <i class="bi bi-plus-lg me-1"></i>Add product
      </RouterLink>
    </div>

    <AlertMessage :message="error" />
    <AlertMessage :message="notice" type="success" />

    <div v-if="loading" class="spinner-border" role="status"></div>

    <div v-else class="card shadow-sm">
      <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
          <thead class="table-light">
            <tr>
              <th class="ps-3">Product</th>
              <th>Category</th>
              <th>Price</th>
              <th>Stock</th>
              <th class="text-end pe-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="product in products" :key="product.id">
              <td class="ps-3">
                <div class="d-flex align-items-center gap-3">
                  <img
                    v-if="product.imageUrl"
                    :src="product.imageUrl"
                    :alt="product.name"
                    class="rounded object-fit-cover bg-light"
                    style="width: 90px; height: 72px"
                  />
                  <span class="fw-semibold">{{ product.name }}</span>
                </div>
              </td>
              <td>{{ product.category }}</td>
              <td>₱{{ product.price.toFixed(2) }}</td>
              <td>{{ product.stock }}</td>
              <td class="text-end pe-3">
                <div class="d-flex gap-2 justify-content-end">
                  <RouterLink
                    :to="`/seller/products/${product.id}/edit`"
                    class="btn btn-outline-primary btn-sm"
                  >Edit</RouterLink>
                  <button
                    class="btn btn-outline-danger btn-sm"
                    :disabled="deleting === product.id"
                    @click="removeProduct(product)"
                  >Delete</button>
                </div>
              </td>
            </tr>
            <tr v-if="!products.length">
              <td colspan="5" class="text-center text-secondary py-5">
                No products yet. Add one to get started.
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>
