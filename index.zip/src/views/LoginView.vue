<script setup>
import { ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import api, { errorMessage } from '../services/api.js'
import { useAuth } from '../stores/auth.js'
import AlertMessage from '../components/AlertMessage.vue'

const router = useRouter()
const route = useRoute()
const { setSession } = useAuth()

const email = ref('')
const password = ref('')
const error = ref('')
const loading = ref(false)

async function login() {
  loading.value = true
  error.value = ''
  try {
    const result = (await api.post('/auth/login', {
      email: email.value.trim(),
      password: password.value,
    })).data

    setSession(result)

    const redirect = route.query.redirect
    const safeRedirect =
      typeof redirect === 'string' && redirect.startsWith('/') && !redirect.startsWith('//')
        ? redirect
        : null

    await router.replace(
      safeRedirect || (result.user.role === 'seller' ? '/seller/products' : '/products'),
    )
  } catch (err) {
    error.value = errorMessage(err)
  } finally {
    loading.value = false
  }
}

function fillDemo(role) {
  email.value = `${role}@example.com`
  password.value = 'Password123!'
}
</script>

<template>
  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-md-7 col-lg-5 col-xl-4">
        <div class="card shadow-sm border-0">
          <div class="card-body p-4 p-md-5">
            <div class="small text-uppercase fw-bold text-secondary mb-2">Welcome back</div>
            <h1 class="h2 fw-bold mb-2">Sign in</h1>
            <p class="text-secondary mb-4">Sign in to shop or manage your products.</p>

            <AlertMessage :message="error" />

            <form @submit.prevent="login">
              <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input
                  id="email"
                  v-model.trim="email"
                  type="email"
                  class="form-control"
                  autocomplete="username"
                  required
                />
              </div>
              <div class="mb-4">
                <label for="password" class="form-label">Password</label>
                <input
                  id="password"
                  v-model="password"
                  type="password"
                  class="form-control"
                  autocomplete="current-password"
                  required
                />
              </div>
              <button class="btn btn-dark w-100 py-2" :disabled="loading">
                {{ loading ? 'Signing in...' : 'Sign in' }}
              </button>
            </form>

            <hr class="my-4" />
            <p class="small text-secondary mb-2">
              Demo accounts (password: <code>Password123!</code>)
            </p>
            <div class="d-flex gap-2 mb-4">
              <button type="button" class="btn btn-outline-secondary btn-sm" @click="fillDemo('customer')">
                Customer
              </button>
              <button type="button" class="btn btn-outline-secondary btn-sm" @click="fillDemo('seller')">
                Seller
              </button>
            </div>
            <p class="mb-0 small">
              New here? <RouterLink to="/register">Create an account</RouterLink>
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
