import { reactive, computed } from 'vue'
import api from '../services/api.js'

const state = reactive({ items: [], total: 0 })
const count = computed(() => state.items.reduce((sum, item) => sum + item.quantity, 0))
function apply(cart) {
  state.items = cart.items || []
  state.total = cart.total || 0
}
export function useCart() {
  async function refresh() { const response = await api.get('/cart'); apply(response.data.data) }
  async function add(productId, quantity = 1) {
    const response = await api.post('/cart', { productId, quantity })
    apply(response.data.data)
  }
  async function update(productId, quantity) {
    const response = await api.patch(`/cart/${productId}`, { quantity })
    apply(response.data.data)
  }
  async function remove(productId) {
    const response = await api.delete(`/cart/${productId}`)
    apply(response.data.data)
  }
  function clear() { apply({ items: [], total: 0 }) }
  return { state, count, refresh, add, update, remove, clear }
}
