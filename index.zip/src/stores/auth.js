import { computed, reactive } from 'vue'

const storedUser = (() => {
  try { return JSON.parse(sessionStorage.getItem('demo_user') || 'null') }
  catch { return null }
})()
const state = reactive({
  token: sessionStorage.getItem('demo_token') || '',
  user: storedUser
})

export function useAuth() {
  const isLoggedIn = computed(() => Boolean(state.token))
  const isSeller = computed(() => isLoggedIn.value && state.user?.role === 'seller')
  const isCustomer = computed(() => isLoggedIn.value && state.user?.role === 'customer')

  function setSession(response) {
    if (!response?.accessToken || !response?.user) throw new Error('Invalid login response')
    state.token = response.accessToken
    state.user = response.user
    sessionStorage.setItem('demo_token', state.token)
    sessionStorage.setItem('demo_user', JSON.stringify(state.user))
  }
  function logout() {
    state.token = ''
    state.user = null
    sessionStorage.removeItem('demo_token')
    sessionStorage.removeItem('demo_user')
  }
  return { state, isLoggedIn, isSeller, isCustomer, setSession, logout }
}
