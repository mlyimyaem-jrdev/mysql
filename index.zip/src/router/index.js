import { createRouter, createWebHistory } from "vue-router";
import { useAuth } from "../stores/auth.js";
import ProductsView from "../views/ProductsView.vue";
import ProductDetailView from "../views/ProductDetailView.vue";
import LoginView from "../views/LoginView.vue";
import RegisterView from "../views/RegisterView.vue";
import CartView from "../views/CartView.vue";
import OrdersView from "../views/OrdersView.vue";
import SellerView from "../views/SellerView.vue";
import ProductFormView from "../views/ProductFormView.vue";
import NotFoundView from "../views/NotFoundView.vue";

const routes = [
  { path: "/", redirect: "/products" },
  { path: "/products", component: ProductsView },
  { path: "/products/:id", component: ProductDetailView },
  { path: "/login", component: LoginView },
  { path: "/register", component: RegisterView },
  { path: "/cart", component: CartView, meta: { role: "customer" } },
  { path: "/orders", component: OrdersView, meta: { role: "customer" } },
  { path: "/seller/products", component: SellerView, meta: { role: "seller" } },
  {
    path: "/seller/products/new",
    component: ProductFormView,
    meta: { role: "seller" },
  },
  {
    path: "/seller/products/:id/edit",
    component: ProductFormView,
    meta: { role: "seller" },
  },
  { path: "/:pathMatch(.*)*", component: NotFoundView },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior: () => ({ top: 0 }),
});
router.beforeEach((to) => {
  const { state, isLoggedIn } = useAuth();
  if (to.meta.role && !isLoggedIn.value)
    return { path: "/login", query: { redirect: to.fullPath } };
  if (to.meta.role && state.user?.role !== to.meta.role)
    return { path: "/products" };
});
export default router;
