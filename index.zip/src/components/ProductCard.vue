<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuth } from '../stores/auth.js'
import { useCart } from '../stores/cart.js'
import { errorMessage } from '../services/api.js'

const props = defineProps({ product: { type: Object, required: true } })
const { isCustomer, isLoggedIn } = useAuth()
const cart = useCart()
const router = useRouter()
const busy = ref(false)
const message = ref('')

async function add() {
  if (!isLoggedIn.value) return router.push('/login')
  if (!isCustomer.value) return
  busy.value = true
  message.value = ''
  try {
    await cart.add(props.product.id)
    message.value = 'Added to cart!'
  } catch (err) {
    message.value = errorMessage(err)
  } finally {
    busy.value = false
  }
}
</script>

<template>
  <article class="card h-100 border-0 shadow-sm overflow-hidden">
    <RouterLink
      :to="`/products/${product.id}`"
      class="bg-light d-flex align-items-center justify-content-center text-decoration-none"
      style="height: 196px"
    >
      <img
        v-if="product.imageUrl"
        :src="product.imageUrl"
        :alt="product.name"
        class="w-100 h-100 object-fit-cover"
        loading="lazy"
      />
      <i v-else class="bi bi-image text-secondary display-4"></i>
    </RouterLink>

    <div class="card-body d-flex flex-column">
      <span class="small text-uppercase fw-bold text-secondary">{{ product.category }}</span>
      <RouterLink :to="`/products/${product.id}`" class="h6 text-decoration-none text-dark mt-2">
        {{ product.name }}
      </RouterLink>

      <div class="mt-auto pt-2">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <strong class="fs-5">₱{{ product.price.toLocaleString('en-PH', { minimumFractionDigits: 2 }) }}</strong>
          <small class="text-secondary">{{ product.stock }} left</small>
        </div>
        <button
          class="btn btn-dark w-100"
          :disabled="busy || !product.stock || (isLoggedIn && !isCustomer)"
          @click="add"
        >
          <i class="bi bi-plus-lg me-1"></i>
          {{ busy ? 'Adding...' : !product.stock ? 'Out of stock' : 'Add to cart' }}
        </button>
        <small v-if="message" class="d-block mt-2 text-secondary">{{ message }}</small>
      </div>
    </div>
  </article>
</template>
